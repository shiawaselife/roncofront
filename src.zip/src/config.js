export const containerMaxW = 'xl:max-w-6xl xl:mx-auto'
